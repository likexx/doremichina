<?php
require_once('userreview.php');

class ReviewList {

protected $reviews = array();

public function __construct() {
}

public function load($teacher_id) {

    $conn = mysql_connect(DAO::SERVER, DAO::USER, DAO::PASSWORD);
    mysql_select_db(DAO::DATABASE, $conn);
    
    $sql = "select * from review where teacher_id='$teacher_id'";

    $result = mysql_query($sql, $conn);
    $num = mysql_num_rows($result);
    error_log('total rows: ' . $num);
    while ($row = mysql_fetch_assoc($result)) {
        $r = new UserReview($row);
        $this->reviews[] = $r;
    }
    
    mysql_close($conn);

}

public function toJsonString() {

    $data='{"reviews":[';
    $num = count($this->reviews);
    $i = 0;
    while ($i < $num) {
        $r = $this->reviews[$i];
        $teacher='{"reviewer_id":' . $r->reviewer_id . ',' .
                 '"spec1_rating":"' . $r->spec1_rating . '",' .
                 '"spec2_rating":"' . $r->spec2_rating . '",' .
                 '"spec3_rating":"' . $r->spec3_rating . '",' .
                 '"comment":"' . $r->comment . '",' .
                 '"timestamp":' . $r->timestamp .
                 '}';
        
        $data = $data . $teacher;
        $i++;
        if ($i < $num) {
            $data = $data . ',';
        }
    }

    $data = $data . ']}';

    error_log('data:' . $num . '    ' . $data);

    return $data;
}

}

?>