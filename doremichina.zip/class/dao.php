<?php

class DAO {

    const SERVER = 'serval.arvixe.com';
    const USER = 'doremi_china';
    const PASSWORD = 'Like1027';
    const DATABASE = 'doremi_china';

}

?>