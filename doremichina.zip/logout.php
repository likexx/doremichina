<?php

setcookie('userId',0,time()-3600);

?>