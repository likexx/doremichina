
var REVIEW = {
	
	postReview:function() {
		var teacher_id=$('#new_review_teacher_id').val();
		var spec1_rating=$('#new_review_spec1_rating').val();
		var spec2_rating=$('#new_review_spec2_rating').val();
		var spec3_rating=$('#new_review_spec3_rating').val();
		var comment=$('#new_review_comment').val();
		
		var review = {
				"teacher_id":teacher_id,
				"spec1_rating":spec1_rating,
				"spec2_rating":spec2_rating,
				"spec3_rating":spec3_rating,
				"comment":comment
		};
		
		console.log(review);
		
	    $.post('./updateReview.php',review, function(data) {
	    	console.log(data);
			var d = YAHOO.lang.JSON.parse(data);

	    	REVIEW.loadReviews(d.teacher_id);
	    	});
		
	},	
	
	loadReviews:function(id) {
		
		var req = {
				id: id
		}
		
		$.post('./loadReviews.php?', req, function(data){
			var d = YAHOO.lang.JSON.parse(data);
			console.log(d);
			var content = "";
			for(i in d.reviews){
				
				var r = d.reviews[i];
				
				content += r.reviewer_id + '<br/>' +
						   r.spec1_rating + '<br/>' +
						   r.spec2_rating + '<br/>' +
						   r.spec3_rating + '<br/>' +
						   r.comment + '<hr>';
			}
//			var e = document.getElementById('DIV_TEACHER_DETAILS_REVIEWS');
//			e.innerHTML=content;
			$('#DIV_TEACHER_DETAILS_REVIEWS').html(content);
		});	
	},
	

		
		
};